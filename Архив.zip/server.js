// const express = require('express');
// const mysql = require('mysql2');

// const app = express();

// const connection = mysql.createConnection({
//   host: 'vertik03.mysql.tools',
//   user: 'vertik03_default',
//   password: '26T3+#buuZ',
//   database: 'vertik03_default'
// });

// connection.connect((err) => {
//   if (err) throw err;
//   console.log('Connected to MySQL database!');
// });

// app.use('/', (req, res) => {
//   res.setHeader('Access-Control-Allow-Origin', '*');
//   res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
//   res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

//   // Your route handling code here
// });

// app.listen(4000, () => {
//   console.log('Server listening on port 4000');
// });
