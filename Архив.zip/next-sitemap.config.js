module.exports = {
  siteUrl: 'https://www.vertikalstar.com/', // Замените на URL вашего сайта
  generateRobotsTxt: true, // Генерировать файл robots.txt (необязательно)
  // exclude: ['/secret-page'], // Список путей, которые нужно исключить из sitemap (необязательно)
  // Дополнительные настройки, см. документацию next-sitemap
};
