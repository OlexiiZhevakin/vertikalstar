export const slider1Data = [
  "/img/blog/page/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty/slider1/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty-1.jpg",
  "/img/blog/page/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty/slider1/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty-2.jpg",
  "/img/blog/page/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty/slider1/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty-3.jpg",
  "/img/blog/page/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty/slider1/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty-4.jpg",
  "/img/blog/page/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty/slider1/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty-5.jpg",
  "/img/blog/page/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty/slider1/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty-6.jpg",
  "/img/blog/page/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty/slider1/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty-7.jpg",
  "/img/blog/page/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty/slider1/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty-8.jpg",
  "/img/blog/page/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty/slider1/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty-9.jpg",
]