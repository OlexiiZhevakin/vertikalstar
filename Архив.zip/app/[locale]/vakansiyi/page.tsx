import Form from "@/app/[locale]/components/form/Form"

const Vakansiyi = () => {
  return(
    <>
      <Form/>
    </>
  )
}

export default Vakansiyi