import styles from './picture.module.scss'

const Picture = () => {
  return(
    <section className={styles.picture}>
      <div className="container">
        <h2>Знайома картина?</h2>

        <div className={styles.inner}>
          
        </div>
      </div>
    </section>
  )
}

export default Picture