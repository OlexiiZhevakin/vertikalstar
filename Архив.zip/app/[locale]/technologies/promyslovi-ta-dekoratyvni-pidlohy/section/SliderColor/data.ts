export const slidercolor = [
  "/img/technologies/page/promyslovi-ta-dekoratyvni-pidlohy/slider-color/kolorovi-pokryttya-dlya-betonnykh-pidloh-5.jpg",
  "/img/technologies/page/promyslovi-ta-dekoratyvni-pidlohy/slider-color/kolorovi-pokryttya-dlya-betonnykh-pidloh-6.jpg",
  "/img/technologies/page/promyslovi-ta-dekoratyvni-pidlohy/slider-color/kolorovi-pokryttya-dlya-betonnykh-pidloh-7.jpg",
  "/img/technologies/page/promyslovi-ta-dekoratyvni-pidlohy/slider-color/kolorovi-pokryttya-dlya-betonnykh-pidloh-8.jpg",
  "/img/technologies/page/promyslovi-ta-dekoratyvni-pidlohy/slider-color/kolorovi-pokryttya-dlya-betonnykh-pidloh-9.jpg",
  "/img/technologies/page/promyslovi-ta-dekoratyvni-pidlohy/slider-color/kolorovi-pokryttya-dlya-betonnykh-pidloh-10.jpg",
]