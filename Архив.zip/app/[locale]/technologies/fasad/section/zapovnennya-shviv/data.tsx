const zapovnennyaShvivData = [
  {
    video: '/img/technologies/page/fasad/zapovnennya-shviv/zapovnennya-shviv-1.mp4'
  }
]

export default zapovnennyaShvivData