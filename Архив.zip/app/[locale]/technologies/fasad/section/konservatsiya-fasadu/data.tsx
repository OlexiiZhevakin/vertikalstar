const konservatsiyaFasaduData = [
  {
    img: "/img/technologies/page/fasad/konservatsiya-fasadu/konservatsiya-fasadu-1.jpg"
  },
  {
    img: "/img/technologies/page/fasad/konservatsiya-fasadu/konservatsiya-fasadu-2.jpg"
  },
  {
    img: "/img/technologies/page/fasad/konservatsiya-fasadu/konservatsiya-fasadu-3.jpg"
  }
]

export default konservatsiyaFasaduData