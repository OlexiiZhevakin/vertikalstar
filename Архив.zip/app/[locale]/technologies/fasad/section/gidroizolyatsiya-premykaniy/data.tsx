const gidroizolyatsiyaPremykaniyData = [
  {
    img: "/img/technologies/page/fasad/gidroizolyatsiya-premykaniy/gidroizolyatsiya-premykaniy-1.jpg"
  },
  {
    img: "/img/technologies/page/fasad/gidroizolyatsiya-premykaniy/gidroizolyatsiya-premykaniy-2.jpg"
  },
  {
    img: "/img/technologies/page/fasad/gidroizolyatsiya-premykaniy/gidroizolyatsiya-premykaniy-3.jpg"
  },
  {
    img: "/img/technologies/page/fasad/gidroizolyatsiya-premykaniy/gidroizolyatsiya-premykaniy-4.jpg"
  },
]

export default gidroizolyatsiyaPremykaniyData