const fasadDataSlider = [
  {
    img: "/img/technologies/page/fasad/slider/fasad-1.jpg",
  },
  {
    img: "/img/technologies/page/fasad/slider/fasad-2.jpg",
  },
  {
    img: "/img/technologies/page/fasad/slider/fasad-3.jpg",
  },
  {
    img: "/img/technologies/page/fasad/slider/fasad-4.jpg",
  },
  {
    img: "/img/technologies/page/fasad/slider/fasad-5.jpg",
  },
  {
    img: "/img/technologies/page/fasad/slider/fasad-6.jpg",
  },
  // {
  //   img: "/img/technologies/page/fasad/slider/fasad-7.jpg",
  //   width: 428
  // },
  {
    img: "/img/technologies/page/fasad/slider/fasad-8.jpg",
  },
  {
    img: "/img/technologies/page/fasad/slider/fasad-9.jpg",
  },
  {
    img: "/img/technologies/page/fasad/slider/fasad-10.jpg",
  }
]

export default fasadDataSlider