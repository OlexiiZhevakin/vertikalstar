const piskostrumynneOchyshchennyaData = [
  {
    img: "/img/technologies/page/fasad/piskostrumynne-ochyshchennya/piskostrumynne-ochyshchennya-1.jpg"
  },
  {
    img: "/img/technologies/page/fasad/piskostrumynne-ochyshchennya/piskostrumynne-ochyshchennya-2.jpg"
  },
  {
    img: "/img/technologies/page/fasad/piskostrumynne-ochyshchennya/piskostrumynne-ochyshchennya-3.jpg"
  },
  {
    img: "/img/technologies/page/fasad/piskostrumynne-ochyshchennya/piskostrumynne-ochyshchennya-4.jpg"
  },
  {
    video: "/img/technologies/page/fasad/piskostrumynne-ochyshchennya/piskostrumynne-ochyshchennya-5.mp4"
  },
  {
    img: "/img/technologies/page/fasad/piskostrumynne-ochyshchennya/piskostrumynne-ochyshchennya-6.jpg"
  },
  {
    img: "/img/technologies/page/fasad/piskostrumynne-ochyshchennya/piskostrumynne-ochyshchennya-7.jpg"
  },
  {
    video: "/img/technologies/page/fasad/piskostrumynne-ochyshchennya/piskostrumynne-ochyshchennya-8.mp4"
  },
]

export default piskostrumynneOchyshchennyaData