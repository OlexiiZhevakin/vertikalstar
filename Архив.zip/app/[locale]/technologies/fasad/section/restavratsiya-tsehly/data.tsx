const restavratsiyaTsehlyData = [
  {
    img: "/img/technologies/page/fasad/restavratsiya-tsehly/restavratsiya-tsehly-1.jpg"
  },
  {
    img: "/img/technologies/page/fasad/restavratsiya-tsehly/restavratsiya-tsehly-2.jpg"
  },
  {
    img: "/img/technologies/page/fasad/restavratsiya-tsehly/restavratsiya-tsehly-3.jpg"
  },
]

export default restavratsiyaTsehlyData