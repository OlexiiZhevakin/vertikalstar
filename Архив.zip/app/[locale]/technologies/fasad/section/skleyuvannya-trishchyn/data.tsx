const skleyuvannyaTrishchynData = [
  {
    img: "/img/technologies/page/fasad/skleyuvannya-trishchyn/skleyuvannya-trishchyn-1.jpg"
  },
  {
    img: "/img/technologies/page/fasad/skleyuvannya-trishchyn/skleyuvannya-trishchyn-2.jpg"
  },
]

export default skleyuvannyaTrishchynData