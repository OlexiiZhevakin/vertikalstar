const khimichnaOchystkaData = [
  {
    img: "/img/technologies/page/fasad/khimichna-ochystka/khimichna-ochystka-1.jpg"
  },
  {
    img: "/img/technologies/page/fasad/khimichna-ochystka/khimichna-ochystka-2.jpg"
  },
  {
    img: "/img/technologies/page/fasad/khimichna-ochystka/khimichna-ochystka-3.jpg"
  },
]
export default khimichnaOchystkaData