const worldData = [
  {
    img: '/img/technologies/page/microcement/world/svitovi-obyekti-1.jpg'
  },
  {
    img: '/img/technologies/page/microcement/world/svitovi-obyekti-2.jpg'
  },
  {
    img: '/img/technologies/page/microcement/world/svitovi-obyekti-3.jpg'
  },
  {
    img: '/img/technologies/page/microcement/world/svitovi-obyekti-4.jpg'
  },
  {
    img: '/img/technologies/page/microcement/world/svitovi-obyekti-5.jpg'
  },
  {
    img: '/img/technologies/page/microcement/world/svitovi-obyekti-6.jpg'
  },
  {
    img: '/img/technologies/page/microcement/world/svitovi-obyekti-7.jpg'
  },
  {
    img: '/img/technologies/page/microcement/world/svitovi-obyekti-8.jpg'
  },
  {
    img: '/img/technologies/page/microcement/world/svitovi-obyekti-9.jpg'
  },
  {
    img: '/img/technologies/page/microcement/world/svitovi-obyekti-10.jpg'
  },
]

export default worldData