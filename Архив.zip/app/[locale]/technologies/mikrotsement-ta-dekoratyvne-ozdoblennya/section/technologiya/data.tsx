const technologiyaData = [
  {
    img: '/img/technologies/page/microcement/technologiya/tekhnolohiya-nanesennya-1.jpg',
    body: 'DUROCRET-DECO FLEX додається до ємності з водою при постійному перемішуванні до отримання однорідної суміші потрібної консистенції.'
  },
  {
    img: '/img/technologies/page/microcement/technologiya/tekhnolohiya-nanesennya-2.jpg',
    body: 'DUROCRET-DECO FLEX додається до ємності з водою при постійному перемішуванні до отримання однорідної суміші потрібної консистенції.'
  },
  {
    img: '/img/technologies/page/microcement/technologiya/tekhnolohiya-nanesennya-3.jpg',
    body: 'Матеріал наноситься зубчастим шпателем 10 мм.'
  },
  {
    img: '/img/technologies/page/microcement/technologiya/tekhnolohiya-nanesennya-4.jpg',
    body: 'Армуюча сітка (160 г/м2) кладеться на ребристу поверхню DUROCRET-DECO FLEX. Після цього сітка вбирається у шар матеріалу та розгладжується гладким краєм шпателя. Поверхня стає відносно гладкою.'
  },
  {
    img: '/img/technologies/page/microcement/technologiya/tekhnolohiya-nanesennya-5.jpg',
    body: 'Армуюча сітка (160 г/м2) кладеться на ребристу поверхню DUROCRET-DECO FLEX. Після цього сітка вбирається у шар матеріалу та розгладжується гладким краєм шпателя. Поверхня стає відносно гладкою.'
  },
  {
    img: '/img/technologies/page/microcement/technologiya/tekhnolohiya-nanesennya-6.jpg',
    body: 'Через 24 години суха та затверділа поверхня DUROCRET-DECO FLEX ґрунтується акриловим ґрунтом UNI-PRIMER.'
  },
  {
    img: '/img/technologies/page/microcement/technologiya/tekhnolohiya-nanesennya-7.jpg',
    body: 'Поки шар грунту ще мокрий наноситься DUROCRET-DECO FLEX або DUROCRET- DECO FINISH (метод «мокрий по мокрому») вибраного кольору шаром завтовшки 1,5 мм і його поверхні надається потрібна текстура.'
  },
  {
    img: '/img/technologies/page/microcement/technologiya/tekhnolohiya-nanesennya-8.jpg',
    body: 'Поки шар грунту ще мокрий наноситься DUROCRET-DECO FLEX або DUROCRET- DECO FINISH (метод «мокрий по мокрому») вибраного кольору шаром завтовшки 1,5 мм і його поверхні надається потрібна текстура.'
  },
  {
    img: '/img/technologies/page/microcement/technologiya/tekhnolohiya-nanesennya-9.jpg',
    body: "Через 24 години поверхня м'яко обробляється наждаком для отримання надгладкої поверхні."
  },
  {
    img: '/img/technologies/page/microcement/technologiya/tekhnolohiya-nanesennya-10.jpg',
    body: "Через 24 години поверхня м'яко обробляється наждаком для отримання надгладкої поверхні."
  },
  {
    img: '/img/technologies/page/microcement/technologiya/tekhnolohiya-nanesennya-11.jpg',
    body: 'Вся поверхня очищується пилососом.'
  },
  {
    img: '/img/technologies/page/microcement/technologiya/tekhnolohiya-nanesennya-12.jpg',
    body: 'Через два - три дні після нанесення, за умови, що поверхня мікроцементного покриття абсолютно суха на неї можна наносити захисні лаки залежно від бажаного ефекту.'
  },
]

export default technologiyaData