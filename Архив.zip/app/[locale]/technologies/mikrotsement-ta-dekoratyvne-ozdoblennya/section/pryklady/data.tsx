const prykladyData = [
  {
    img: '/img/technologies/page/microcement/priklad/mikrotsement-ta-dekoratyvne-ozdoblennya-1.jpg'
  },
  {
    img: '/img/technologies/page/microcement/priklad/mikrotsement-ta-dekoratyvne-ozdoblennya-2.jpg'
  },
  {
    img: '/img/technologies/page/microcement/priklad/mikrotsement-ta-dekoratyvne-ozdoblennya-3.jpg'
  },
  {
    img: '/img/technologies/page/microcement/priklad/mikrotsement-ta-dekoratyvne-ozdoblennya-4.jpg'
  },
  {
    img: '/img/technologies/page/microcement/priklad/mikrotsement-ta-dekoratyvne-ozdoblennya-5.jpg'
  },
  {
    img: '/img/technologies/page/microcement/priklad/mikrotsement-ta-dekoratyvne-ozdoblennya-6.jpg'
  },
  {
    img: '/img/technologies/page/microcement/priklad/mikrotsement-ta-dekoratyvne-ozdoblennya-7.jpg'
  },
  {
    img: '/img/technologies/page/microcement/priklad/mikrotsement-ta-dekoratyvne-ozdoblennya-8.jpg'
  },
]

export default prykladyData