import Form from '@/app/[locale]/components/form/Form';
import styles from './page.module.scss';

const ByuroRekonstruktsiyi = () =>{
  return(
    <>
    <Form/>
    </>
  )
}

export default ByuroRekonstruktsiyi;