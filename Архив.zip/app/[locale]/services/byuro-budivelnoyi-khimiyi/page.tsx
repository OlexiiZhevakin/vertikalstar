import Form from '@/app/[locale]/components/form/Form';
import styles from './page.module.scss';

const ByuroBudivelnoyiKhimiyi = () =>{
  return(
    <>
    <Form/>
    </>
  )
}

export default ByuroBudivelnoyiKhimiyi;