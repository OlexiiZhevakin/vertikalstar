import Form from '@/app/[locale]/components/form/Form';
import Head from './section/head/Head';
import Proect from './section/proect/Proect';

const ProektuvannyaTekhnolohiy = () =>{
  return(
    <>
    <Head/>
    <Proect/>
    <Form/>
    </>
  )
}

export default ProektuvannyaTekhnolohiy;