import Form from "@/app/[locale]/components/form/Form"
import After from "./section/After/After"
import Before from "./section/Before/Before"


const GidroizolyatsiyaTerrasy = () => {
  return (
    <>
      <Before />
      <After />
      <Form/>
    </>
  )
}

export default GidroizolyatsiyaTerrasy