export const data = [
  "/img/portfolio/2023/gidroizolyatsiya-terrasy/before/vyd-do-1.jpg",
  "/img/portfolio/2023/gidroizolyatsiya-terrasy/before/vyd-do-2.jpg",
  "/img/portfolio/2023/gidroizolyatsiya-terrasy/before/vyd-do-3.jpg",
  "/img/portfolio/2023/gidroizolyatsiya-terrasy/before/vyd-do-4.jpg",
]