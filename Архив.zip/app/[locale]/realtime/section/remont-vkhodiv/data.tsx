const dataSlider3 = [
  {
    video: "/img/real/gidroizolyatsiya-terrasy/remont-vkhodiv/remont-vkhodiv-1.mp4"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/remont-vkhodiv/remont-vkhodiv-2.jpg"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/remont-vkhodiv/remont-vkhodiv-3.jpg"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/remont-vkhodiv/remont-vkhodiv-4.jpg"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/remont-vkhodiv/remont-vkhodiv-5.jpg"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/remont-vkhodiv/remont-vkhodiv-6.jpg"
  },
]

export default dataSlider3