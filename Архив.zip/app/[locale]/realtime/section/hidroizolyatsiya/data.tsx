const hidroizolyatsiyaData = [
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-1.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-2.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-3.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-4.jpg"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-5.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-6.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-7.jpg"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-8.jpg"
  },
  {
    video: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-9.mp4"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-10.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-11.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-12.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-13.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-14.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-15.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-16.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-17.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-18.jpg",
    width: 450
  },
  {
    video: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-19.mp4"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-20.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-21.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-22.jpg"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-23.jpg"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-24.jpg"
  },
  {
    video: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-25.mp4"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-26.jpg"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-27.jpg"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-28.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-29.jpg",
    width: 450
  },
  {
    video: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-30.mp4",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-31.jpg"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-32.jpg"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-33.jpg"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-34.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-35.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-36.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-37.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-38.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-39.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-40.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-41.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-42.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-43.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-44.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-45.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-46.jpg"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-47.jpg"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-48.jpg",
    width: 450
  },
  {
    video: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-49.mp4"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-50.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-51.jpg",
    width: 450
  },
  {
    video: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-52.mp4"
  },
  {
    video: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-53.mp4"
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-54.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-55.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-56.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-57.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-58.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-59.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-60.jpg",
    width: 450
  },
  {
    img: "/img/real/gidroizolyatsiya-terrasy/hidroizolyatsiya/hidroizolyatsiya-61.jpg",
    width: 450
  },
]

export default hidroizolyatsiyaData