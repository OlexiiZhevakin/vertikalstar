const inshiData = [
  {
    img: "/img/real/rekonstruktsiya-dvokhpoverkhovoho-budynku/inshi/rekonstruktsiya-dvokhpoverkhovoho-budynku-1.jpg",
  },
  {
    img: "/img/real/rekonstruktsiya-dvokhpoverkhovoho-budynku/inshi/rekonstruktsiya-dvokhpoverkhovoho-budynku-2.jpg",
  },
  {
    img: "/img/real/rekonstruktsiya-dvokhpoverkhovoho-budynku/inshi/rekonstruktsiya-dvokhpoverkhovoho-budynku-3.jpg",
  },
  {
    img: "/img/real/rekonstruktsiya-dvokhpoverkhovoho-budynku/inshi/rekonstruktsiya-dvokhpoverkhovoho-budynku-4.jpg",
  },
  {
    img: "/img/real/rekonstruktsiya-dvokhpoverkhovoho-budynku/inshi/rekonstruktsiya-dvokhpoverkhovoho-budynku-5.jpg",
  },
  {
    img: "/img/real/rekonstruktsiya-dvokhpoverkhovoho-budynku/inshi/rekonstruktsiya-dvokhpoverkhovoho-budynku-6.jpg",
  },
  {
    img: "/img/real/rekonstruktsiya-dvokhpoverkhovoho-budynku/inshi/rekonstruktsiya-dvokhpoverkhovoho-budynku-7.jpg",
  },
  {
    img: "/img/real/rekonstruktsiya-dvokhpoverkhovoho-budynku/inshi/rekonstruktsiya-dvokhpoverkhovoho-budynku-8.jpg",
  }
]

export default inshiData