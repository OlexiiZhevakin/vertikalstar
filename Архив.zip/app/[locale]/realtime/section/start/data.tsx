const startData = [
  {
    img: "/img/real/1.jpg",
  },
  {
    img: "/img/real/2.jpg",
  },
  // {
  //   img: "/img/real/3.jpg",
  // },
  // {
  //   img: "/img/real/4.jpg",
  // }
]

export default startData