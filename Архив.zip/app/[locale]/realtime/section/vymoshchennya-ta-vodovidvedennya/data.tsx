const vodovidvedennyaData = [
  {
    video: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-1.mp4",
  },
  {
    video: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-2.mp4",
  },
  {
    video: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-3.mp4",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-4.jpg",
  },
  {
    video: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-5.mp4",
  },
  {
    video: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-6.mp4",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-7.jpg",
  },
  {
    video: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-8.mp4",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-9.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-10.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-11.jpg",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-12.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-13.jpg",
    width: 450
  },
  {
    video: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-14.mp4",
  },
  {
    video: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-15.mp4",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-16.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-17.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-18.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-19.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-20.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-21.jpg",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-22.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-23.jpg",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-24.jpg",
    width: 450
  },
  {
    video: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-25.mp4",
  },
  {
    video: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-26.mp4",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-27.jpg",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-28.jpg",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-29.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-30.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-31.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-32.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-33.jpg",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-34.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-35.jpg",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-36.jpg",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-37.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-38.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-39.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-40.jpg",
    width: 450
  },
  {
    video: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-41.mp4",
  },
  {
    video: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-42.mp4",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-43.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-44.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-45.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-46.jpg",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-47.jpg",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-48.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-49.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-50.jpg",
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-51.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-52.jpg",
    width: 450
  },
  {
    image: "/img/real/slider3/vymoshchennya-ta-vodovidvedennya-53.jpg",
  },
]

export default vodovidvedennyaData