const blogHomedData = [{
  link: '/article/sekreti-yak-polehshyty-zhyttya-mulyaru',
  image: '/img/blog/5-sekretiv-yak-polehshyty-zhyttya-mulyaru.jpg',
  title: 'Як покращити розчин для цегляної кладки ?',
  date: '13.04.2023',
},
{
  link: '/article/remmers-tsikavi-fakty-o-kompaniyi',
  image: '/img/blog/remmers-tsikavi-fakty-o-kompaniyi.jpg',
  title: 'REMMERS – цікаві факти про компанію',
  date: '06.02.2023',
},
{
  link: '/article/hidroizolyatsiya-i-vydy-ozdoblennya-baseynu',
  image: '/img/blog/hidroizolyatsiya-i-vydy-ozdoblennya-baseynu.jpg',
  title: 'Гідроізоляція та види оздоблення басейну',
  date: '17.08.2023',
},
]

export default blogHomedData;