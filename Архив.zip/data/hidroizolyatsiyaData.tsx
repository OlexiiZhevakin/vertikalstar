const hidroizolyatsiyaData = [{
  imageWebp: '/img/technologies/page/hidro/gidroizolyacziya-metodom-inekczij.webp',
  image: '/img/technologies/page/hidro/gidroizolyacziya-metodom-inekczij.jpg',
  title: "Гідроізоляція методом ін'єктування",
  link: '/technologies/hidroizolyatsiya/hidroizolyatsiya-metodom-inyektuvannya',
 },
 {
  imageWebp: '/img/technologies/page/hidro/gidroizolyacziya-ploskih-krovel.webp',
  image: '/img/technologies/page/hidro/gidroizolyacziya-ploskih-krovel.jpg',
  title: 'Гідроізоляція плоских покрівель',
  link: '',
 },
 {
  imageWebp: '/img/technologies/page/hidro/gidroizolyacziya-fundamentov.webp',
  image: '/img/technologies/page/hidro/gidroizolyacziya-fundamentov.jpg',
  title: 'Гідроізоляція фундаментів',
  link: '',
 },
 {
  imageWebp: '/img/technologies/page/hidro/hidroizolyatsiya-balkoniv-ta-teras.webp',
  image: '/img/technologies/page/hidro/hidroizolyatsiya-balkoniv-ta-teras.jpg',
  title: 'Гідроізоляція балконів та терас',
  link: '',
 },
 {
  imageWebp: '/img/technologies/page/hidro/gidroizolyacziya-bassejnov.webp',
  image: '/img/technologies/page/hidro/gidroizolyacziya-bassejnov.jpg',
  title: 'Гідроізоляція басейнів',
  link: '',
 },
 {
  imageWebp: '/img/technologies/page/hidro/gidroizolyacziya-dushevyh-i-sanuzlov.webp',
  image: '/img/technologies/page/hidro/gidroizolyacziya-dushevyh-i-sanuzlov.jpg',
  title: 'Гідроізоляція душових та санвузлів',
  link: '',
 },
 {
  imageWebp: '/img/technologies/page/hidro/hidroizolyatsiya-pidvaliv.webp',
  image: '/img/technologies/page/hidro/hidroizolyatsiya-pidvaliv.jpg',
  title: 'Гідроізоляція підвалів',
  link: '',
 },
 {
  imageWebp: '/img/technologies/page/hidro/gidroizolyacziya-rezervuarov.webp',
  image: '/img/technologies/page/hidro/gidroizolyacziya-rezervuarov.jpg',
  title: 'Гідроізоляція резервуарів',
  link: '',
 },
 {
  imageWebp: '/img/technologies/page/hidro/avariyna-zupynka-protikannya.webp',
  image: '/img/technologies/page/hidro/avariyna-zupynka-protikannya.jpg',
  title: 'Аварійна зупинка протікання',
  link: '',
 },
 {
  imageWebp: '/img/technologies/page/hidro/gidroizolyacziya-prohodnyh-elementov-deformaczionnyh-shvov.webp',
  image: '/img/technologies/page/hidro/gidroizolyacziya-prohodnyh-elementov-deformaczionnyh-shvov.jpg',
  title: 'Гідроізоляція прохідних елементів та деформаційних швів',
  link: '',
 },
 {
  imageWebp: '/img/technologies/page/hidro/gidroizolyacziya-metodom-inekczij.webp',
  image: '/img/technologies/page/hidro/gidroizolyacziya-metodom-inekczij.jpg',
  title: 'Фундамент та цоколі',
  link: '',
 },
 {
  imageWebp: '/img/technologies/page/hidro/gidroizolyacziya-zelenyh-krovel.webp',
  image: '/img/technologies/page/hidro/gidroizolyacziya-zelenyh-krovel.jpg',
  title: 'Гідроізоляція зеленої покрівлі',
  link: '',
 },
]

export default hidroizolyatsiyaData;