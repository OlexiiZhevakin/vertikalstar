const blogData = [
  {
    image: '/img/blog/5-sekretiv-yak-polehshyty-zhyttya-mulyaru.jpg',
    link: '/article/sekreti-yak-polehshyty-zhyttya-mulyaru',
    title: 'Як покращити розчин для цегляної кладки?'
  },
  {
    image: '/img/blog/remmers-tsikavi-fakty-o-kompaniyi.jpg',
    link: '/article/remmers-tsikavi-fakty-o-kompaniyi',
    title: 'REMMERS – цікаві факти про компанію'
  },
  {
    image: '/img/blog/osoblyvosti-betonuvannya-u-litnyu-speku.jpg',
    link: '/article/osoblyvosti-betonuvannya-u-litnyu-speku',
    title: 'Особливості бетонування у літню спеку'
  },
  {
    image: '/img/blog/hidroizolyatsiya-i-vydy-ozdoblennya-baseynu.jpg',
    link: '/article/hidroizolyatsiya-i-vydy-ozdoblennya-baseynu',
    title: 'Гідроізоляція та види оздоблення басейну'
  },
  {
    image: '/img/blog/mramor.jpg',
    link: '/article/yak-zakhystyty-pidlohy-z-marmurovoyi-krykhty',
    title: 'Як захистити підлогу з мармурової крихти'
  },
]

export default blogData